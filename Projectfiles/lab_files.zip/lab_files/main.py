# %matplotlib inline
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt


"""
df = pd.read_csv("AirPassengers.csv")
df = df.set_index('Month')
df.plot()
"""


'''
df = pd.read_csv("gioiellerie.csv")
#df['Date'] = df['year'].map(str) + '-' + df['month'].map(str)
#df = df.set_index('Date')
fig = plt.figure(figsize=(8,4))
plt.plot(df.sales,label="US retail sales: jewelry")
'''


df = pd.read_csv("FilRouge.csv")
plt.plot(df.sales,label="TV sales",marker='o')
plt.grid()

plt.legend()
#plt.xticks(rotation=90)
plt.show()

