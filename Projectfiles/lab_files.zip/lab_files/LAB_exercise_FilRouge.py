import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv(r"C:\Users\mediaworld\PycharmProjects\Predictive_Analytics\FilRouge.csv")
df.head()

plt.figure(figsize=(8,4))
plt.plot(df.sales,label="FilRouge")
plt.legend()
plt.show()
