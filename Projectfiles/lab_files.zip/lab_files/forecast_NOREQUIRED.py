# import the packages
import pandas as pd
import numpy as np
from statsmodels.tsa.statespace.sarimax import SARIMAX
import matplotlib.pyplot as plt

# Preprocessing, log - diff transform
df = pd.read_csv(r'C:\Users\mohamedalie.kamara\PycharmProjects\OperationalAnalytics\FilRouge.csv', header=0)
aSales = df['sales'].to_numpy() # array of sales data

data = aSales
n_periods = 4

model = SARIMAX(aSales, order=(0,2,2), seasonal_order=(0,1,0,4))
fitted, confint = model.predict(n_periods=n_periods, return_conf_int=True)
tindex = np.arange(df.index[-1]+1,df.index[-1]+n_periods+1)

# series, for plotting
fitted_series = pd.Series(fitted, index=tindex)
lower_series = pd.Series(confint[:, 0], index=tindex)
upper_series = pd.Series(confint[:, 1], index=tindex)

# Plot
plt.plot(data)
plt.plot(fitted_series, color='darkgreen')
plt.fill_between(lower_series.index, lower_series, upper_series,
color='k', alpha=.15)
plt.title("SARIMAX")
plt.show()

# Vittorio Maniezzo - University of Bologna
pass