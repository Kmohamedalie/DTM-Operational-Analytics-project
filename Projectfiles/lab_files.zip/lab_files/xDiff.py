import pandas as pd
import matplotlib.pyplot as plt

ds = pd.read_csv(r"C:\Users\mediaworld\PycharmProjects\Predictive_Analytics\BoxJenkins.csv")
X = ds.Passengers.values
train_size = int(len(X) * 0.66)
train, test = X[0:train_size], X[train_size:len(X)]
print('Observations: %d' % (len(X)))
print('Training Observations: %d' % (len(train)))
print('Testing Observations: %d' % (len(test)))
# xdiff = [X[i+1] - X[i] for i in range(len(X) - 1)]
xdiff = [X[i] - X[i-1] for i in range(1,len(X))]

plt.plot(xdiff)
# plt.ylabel("Passengers")
plt.title("BoxJenkins Passenger diff")
# plt.plot([None for i in train] + [x for x in test])
plt.show()