####### ********** Xgboost and Random Forest ************************++


# ********** function 1. Xgboost  ****************************
def Xgboost(data, lookback, colname, columnIndex):
    """
    The function returns the and predicted values from
    the data given following parameters
    :param data:
    :param lookback:
    :param colname:
    :return:
    """
    # import all necessary libraries
    from xgboost import XGBRegressor
    import pandas as pd
    from pandas import MultiIndex, Int64Index
    import matplotlib.pyplot as plt
    import numpy as np

    df = pd.read_csv(data, usecols=[columnIndex], names=[colname], header=0)

    # split into train and test sets
    # rolling window dataset
    # lookback = 12
    dataset = pd.DataFrame()

    # for dynamic column accessing
    colname = str(colname)

    for i in range(lookback, 0, -1):
        for i in range(10, 0, -1):
            dataset['t-' + str(i)] = df[str(colname)].shift(i)
            dataset['t'] = df[str(colname)].values
    dataset = dataset[lookback:]  # removes the first lookback columns

    # train test split
    x = dataset.iloc[:, :-1]
    y = dataset.iloc[:, -1]
    x_train, xtest = x[:-12], x[-12:]
    y_train, ytest = y[:-12], y[-12:]

    # fit model
    model = XGBRegressor(objective='reg:squarederror', n_estimators=1000)
    model.fit(x_train, y_train)

    # make a one-step prediction
    yhat = model.predict(xtest)

    # plot the chart
    plt.plot(y_train.index, y_train, "-o", label="train")
    plt.plot(ytest.index, ytest, "-o", label="actual")
    plt.plot(ytest.index, yhat, "-o", label="forecast")
    plt.title("Boxjenkins with Xgboost")
    plt.legend()
    plt.show()


# *********** function 2. Random Forest**************
def RandomForest(data, lookback, colname, columnIndex):
    """
    The function returns the and predicted values from
    the data given following parameters
    :param data:
    :param lookback:
    :param colname:
    :return:
    """

    # import liabraries
    from sklearn.datasets import make_regression
    import pandas as pd
    from pandas import MultiIndex, Int64Index
    import matplotlib.pyplot as plt
    import numpy as np
    from sklearn.ensemble import RandomForestRegressor
    from sklearn.feature_selection import RFE
    from sklearn.metrics import mean_absolute_error

    df = pd.read_csv(data)

    # split into train and test sets
    # rolling window dataset
    dataset = pd.DataFrame()

    # for dynamic column accessing
    colname = str(colname)

    for i in range(lookback, 0, -1):
        for i in range(10, 0, -1):
            dataset['t-' + str(i)] = df[str(colname)].shift(i)
            dataset['t'] = df[str(colname)].values
    dataset = dataset[lookback:]  # removes the first lookback columns

    # train test split
    x = dataset.iloc[:, :-1]
    y = dataset.iloc[:, -1]
    x_train, xtest = x[:-12], x[-12:]
    y_train, ytest = y[:-12], y[-12:]

    # fit model
    model = RandomForestRegressor(n_estimators=1000, random_state=1)
    """min_samples_split=2, min_samples_leaf=1, min_weight_fraction_leaf=0.0, 
                                  max_features=1.0, max_leaf_nodes=None, min_impurity_decrease=0.0, 
                                  bootstrap=True, oob_score=False, n_jobs=None, random_state=None, 
                                  verbose=0, warm_start=False, ccp_alpha=0.0, max_samples=None)
                                  """
    model.fit(x_train, y_train)

    # make a one-step prediction
    yhat = model.predict(xtest)

    # plot the chart
    plt.plot(y_train.index, y_train, "-o", label="train")
    plt.plot(ytest.index, ytest, "-o", label="actual")
    plt.plot(ytest.index, yhat, "-o", label="forecast")
    plt.title("Boxjenkins with Random forest")
    plt.legend()
    plt.show()

    ### ************* Plot the decision tree  *************
    # Stats about the trees in random forest
    # random forest for making predictions for regression

    n_nodes = []
    max_depths = []
    for ind_tree in model.estimators_:
        n_nodes.append(ind_tree.tree_.node_count)
        max_depths.append(ind_tree.tree_.max_depth)
    print(f'Average number of nodes {int(np.mean(n_nodes))}')
    print(f'Average maximum depth {int(np.mean(max_depths))}')

    # plot first tree (index 0)
    from sklearn.tree import plot_tree
    fig = plt.figure(figsize=(15, 10))
    plot_tree(model.estimators_[0],
              max_depth=2,
              feature_names=dataset.columns[:-1],
              class_names=dataset.columns[-1],
              filled=True, impurity=True,
              rounded=True)
    plt.title('Tree plot with max-deth of 2')
    plt.show()


### function 3. User-choice *******************
def choice(data, lookback, colname, columnIndex):
    """
    The function give the user the opportunity
    to choose between Xgboost or Random Forest
    option 1: Xgboost
    option 2: Random Forest
    :return:
    """
    print("Please select your alogorithm of choice\n 0 for xgboost and 1 for Randomforest")
    answer = int(input('enter here: '))
    if answer == 0:
        return Xgboost(data, lookback, colname, columnIndex)
    else:
        return RandomForest(data, lookback, colname, columnIndex)

# assign the choice to an object
Prediction = choice('Boxjenkins.csv',12,'Passengers',1)
Prediction
