# import liabraries
from sklearn.ensemble import RandomForestRegressor
from sklearn.datasets import make_regression
import pandas as pd
from pandas import MultiIndex, Int64Index
import matplotlib.pyplot as plt
import numpy as np

df = pd.read_csv(r'C:BoxJenkins.csv', usecols=[1], names=['Passengers'],header=0)

# split into train and test sets
# rolling window dataset
dataset = pd.DataFrame()

for i in range(10, 0, -1):
  dataset['t-' + str(i)] = df.Passengers.shift(i)
  dataset['t'] = df.Passengers.values
dataset = dataset[10:] # df starts from 0

# train test split
x = dataset.iloc[:, :-1]
y = dataset.iloc[:, -1]
x_train, xtest = x[:-12], x[-12:]
y_train, ytest = y[:-12], y[-12:]

# fit model
model = RandomForestRegressor(n_estimators=1000)
"""min_samples_split=2, min_samples_leaf=1, min_weight_fraction_leaf=0.0, 
                              max_features=1.0, max_leaf_nodes=None, min_impurity_decrease=0.0, 
                              bootstrap=True, oob_score=False, n_jobs=None, random_state=None, 
                              verbose=0, warm_start=False, ccp_alpha=0.0, max_samples=None)
                              """
model.fit(x_train, y_train)

# make a one-step prediction
yhat = model.predict(xtest)


# *** plot the chart **
# plt.plot([None for i in y_train] + [x for x in ytest], "-o", label="actual")
# plt.plot([None for i in y_train] + [x for x in yhat], "-o", label="forecast")
# plot the chart
plt.plot(y_train.index,y_train, "-o", label="train")
plt.plot(ytest.index, ytest, "-o", label="actual")
plt.plot(ytest.index,yhat, "-o", label="forecast")
plt.title("Boxjenkins with RandomForest")
plt.legend()
plt.show()

### ************* Plot the decision tree  *************
# Stats about the trees in random forest
# random forest for making predictions for regression
from sklearn.ensemble import RandomForestRegressor
from sklearn.feature_selection import RFE
from sklearn.metrics import mean_absolute_error

n_nodes = []
max_depths = []
for ind_tree in model.estimators_:
    n_nodes.append(ind_tree.tree_.node_count)
    max_depths.append(ind_tree.tree_.max_depth)
print(f'Average number of nodes {int(np.mean(n_nodes))}')
print(f'Average maximum depth {int(np.mean(max_depths))}')

# plot first tree (index 0)
from sklearn.tree import plot_tree
fig = plt.figure(figsize=(15, 10))
plot_tree(model.estimators_[0],
    max_depth=2,
    feature_names=dataset.columns[:-1],
    class_names=dataset.columns[-1],
    filled=True, impurity=True,
    rounded=True)
plt.title('Tree plot with max-deth of 2')
plt.show()