import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv(r"C:\Users\mediaworld\PycharmProjects\Predictive_Analytics\FilRougePython.csv")
df.head()

plt.figure(figsize=(8,4))
plt.plot(df['sales'],label="Sales value",marker="o")
plt.plot(df['regr'],label="Regressor",marker="o")
plt.title("Linear trend Model")
plt.ylabel("Sales")
plt.legend()
plt.show()


# linear trend calculations in python
stats = df[['t','sales']]
stats['y_avg'] = stats['sales'] - (sum(stats['sales'])/len(stats['sales']))
stats['x_avg'] = stats['t'] - round((sum(stats['t'])/len(stats['t'])),2)