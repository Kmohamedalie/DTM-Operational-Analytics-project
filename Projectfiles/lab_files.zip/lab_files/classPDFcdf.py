from scipy.stats import norm
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

dom = np.arange(-5, 5, 0.001)
mean = 0.0
plt.plot(dom, norm.pdf(dom, mean, 1), label="std=1")
plt.legend()
plt.title("Normal PDF")
plt.show()

plt.plot(dom, norm.cdf(dom, mean, 1), label="std=1")
# plt.plot(dom, norm.cdf(dom, mean, 0.5), label="std=0.5")
# plt.plot(dom, norm.cdf(dom, mean, 2), label="std=2")
plt.legend()
plt.title("Normal CDF")
plt.show()


pass

