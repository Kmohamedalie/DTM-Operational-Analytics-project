# import and test
from dm_test import dm_test
if __name__ == '__main__':
   sarimax_pred = testForecast.squeeze() #[417.662,381.815,423.952,469.055, 471.502, 547.532, 639.609,596.040, 477.471, 445.010, 368.674,414.231]
   Xgboost_pred =  yfore.squeeze() #[416.999,390.999,418.999,461.000, 471.999, 535.000, 622.000,606.000, 507.999, 461.000, 390.000, 431.999]
   actual = testY.squeeze() # [417,391,419,461,472,535,622,606,508,461,390,432]
   rt = dm_test(actual, MLP, LSTM, h=1, crit="MSE")
   print(rt)


passs