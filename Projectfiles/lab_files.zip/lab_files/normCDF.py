import math

from scipy.stats import norm
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
# example of standardization
from sklearn.preprocessing import StandardScaler

df = pd.read_csv(r"C:\Users\mediaworld\PycharmProjects\Predictive_Analytics\traffico16.csv") # dataframe (series)
npa = df['ago1'].to_numpy() # numpy array

# step 3 standardization log difference
# fit transform
df_ago1 = np.array(npa).reshape(len(npa), 1)
transformer = StandardScaler()
transformer.fit(df_ago1)
# difference transform
transformed = transformer.transform(df_ago1)

Mean = transformed.mean()
Std = transformed.std()
dom = np.arange(-2,1,0.01) # domain of x values
# plot the value
plt.plot(dom, norm.cdf(dom,Mean, Std), label=f"std:{int(Std)}")
plt.title("traffico CDF")
plt.legend()
plt.show()

pass


