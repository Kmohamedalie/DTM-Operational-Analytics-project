# import the packages
import pandas as pd
import numpy as np
from statsmodels.tsa.statespace.sarimax import SARIMAX
import matplotlib.pyplot as plt
from statsmodels.tsa.stattools import acf

# Preprocessing, log - diff transform
df = pd.read_csv('monthly_milk_production.csv', header=0)
aProd = df['Production'].to_numpy() # array of sales data
logdata = np.log(aProd ) # log transform

logdiff = pd.Series(logdata).diff() # logdiff transform

# Preprocessing, train and test set
cutpoint = int(0.7*len(logdiff))
train = aProd [:156]
test = aProd [156:]


# Postprocessing, reconstruction
sarima_model = SARIMAX(train, order=(0,2,2), seasonal_order=(0,1,0,4))
sfit = sarima_model.fit()


# ***** Predictions in-sample: ********
ypred = sfit.predict(start=0,end=len(train))
plt.plot(train)
plt.plot(ypred)
plt.xlabel('time');plt.ylabel('Production')
plt.title("Production and prediction")
plt.show()

# **** Forecast, out-of-sample *********
forewrap = sfit.get_forecast(steps=12)
forecast_ci = forewrap.conf_int()
forecast_val = forewrap.predicted_mean
plt.plot(train)
plt.fill_between(np.linspace(len(train),len(train)+12,12),
forecast_ci[:, 0],
forecast_ci[:, 1], color='k', alpha=.25)
plt.plot(np.linspace(len(train),len(train)+12,12),forecast_val)
plt.xlabel('Date');
plt.ylabel('Production')
plt.title("Forecast out-of-sample")
plt.show()


######## ****************** Accuracy metrics ************************
def forecast_accuracy(forecast, actual):
    mape = np.mean(np.abs(forecast - actual)/np.abs(actual)) # MAPE
    me = np.mean(forecast - actual) # ME
    mae = np.mean(np.abs(forecast - actual)) # MAE
    mpe = np.mean((forecast - actual)/actual) # MPE
    rmse = np.mean((forecast - actual)**2)**.5 # RMSE
    corr = np.corrcoef(forecast, actual)[0,1] # correlation coeff
    mins = np.amin(np.hstack([forecast[:,None], actual[:,None]]), axis=1)
    maxs = np.amax(np.hstack([forecast[:,None], actual[:,None]]), axis=1)
    minmax = 1 - np.mean(mins/maxs) # minmax
    acf1 = acf(forecast-actual)[1] # ACF1
    return({'mape':mape, 'me':me, 'mae': mae, 'mpe': mpe, 'rmse':rmse,'acf1':acf1, 'corr':corr, 'minmax':minmax})

# instatiate the values to calculate the metric evaluation
forecast_values = np.array(forecast_val)
actual_vaues = np.array(test)

# output the accuracy
print(forecast_accuracy(forecast_values, test))
