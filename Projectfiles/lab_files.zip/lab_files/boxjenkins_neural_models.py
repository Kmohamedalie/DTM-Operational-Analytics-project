import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv(r"C:\Users\mediaworld\PycharmProjects\Predictive_Analytics\BoxJenkins.csv")
dataset = df.Passenger.values

# converts an array of values into two np arrays
def create_dataset(dataset, look_back=1):
    dataX, dataY = [], []
    for i in range(len(dataset) - look_back):
            a = dataset[i:(i + look_back)]
            dataX.append(a)
            dataY.append(dataset[i + look_back])
    return np.array(dataX), np.array(dataY)



data = create_dataset(dataset)
print(data)





"""
plt.figure(figsize=(8,4))
plt.plot(df.Passengers,label="BoxJenkins passengers")
plt.legend()
plt.show()
"""