import math

from scipy.stats import norm
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
# example of standardization
from sklearn.preprocessing import StandardScaler

df = pd.read_csv(r"C:\Users\mediaworld\PycharmProjects\Predictive_Analytics\traffico16.csv") # dataframe (series)
npa = df['ago1'].to_numpy() # numpy array

# step 3 standardization log difference
# fit transform
df_ago1 = np.array(npa).reshape(len(npa), 1)
transformer = StandardScaler()
transformer.fit(df_ago1)
# difference transform
transformed = transformer.transform(df_ago1)

Mean = transformed.mean()
Std = transformed.std()
dom = np.arange(-2,1,0.01) # domain of x values


# self define NORMpdf function
def NORMpdf(x,Mean,Std):
    import numpy as np
    X = x.copy()
    X = X.astype(int)

    e = 2.718281828459045
    power = (-(((dom - Mean) ** 2) / (2 * Std * Std)))
    eulerp = e**power
    fx = (1/np.sqrt(2*3.123*Std**2))*eulerp
    return fx

# plt.plot(dom, NORMpdf(dom, Mean, Std), label=f'std: {Std}')
plt.plot(dom, norm.pdf(dom, Mean, Std), label=f'std: {Std}')
plt.title("traffico PDF")
plt.legend()
plt.show()

pass
