# example of standardization
from sklearn.preprocessing import StandardScaler

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

ds = pd.read_csv(r"C:\Users\mohamedalie.kamara\PycharmProjects\OperationalAnalytics\FilRouge.csv")
X = ds.sales.values

# step 1 log.
# take the logarithm of the original dataset
log_x = np.log(X)

# step 2 diff.
# log diff minus previous value
log_diff = [log_x[i] - log_x[i-1] for i in range(1,len(log_x))]


# step 3 standardization log difference
# fit transform
log_diff = np.array(log_diff).reshape(len(log_diff), 1)
transformer = StandardScaler()
transformer.fit(log_diff)
# difference transform
transformed = transformer.transform(log_diff)
print(f' Transformed: {transformed}')

# step 4 plot standardized log difference transformed
plt.plot(transformed)
plt.title("standardized log diff transformed")
plt.show()

# step 5 invert standard log difference transformed
inverted = transformer.inverse_transform(transformed)
print(f'Inverted: {inverted}')

pass