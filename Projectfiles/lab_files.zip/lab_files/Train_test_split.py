import pandas as pd
import matplotlib.pyplot as plt

ds = pd.read_csv(r"C:\Users\mediaworld\PycharmProjects\Predictive_Analytics\BoxJenkins.csv")
X = ds.Passengers.values
train_size = int(len(X) * 0.66)
train, test = X[0:train_size], X[train_size:len(X)]
print('Observations: %d' % (len(X)))
print('Training Observations: %d' % (len(train)))
print('Testing Observations: %d' % (len(test)))
plt.plot(train)
plt.ylabel("Passengers")
plt.title("BoxJenkins Passenger")
plt.plot([None for i in train] + [x for x in test])
plt.show()