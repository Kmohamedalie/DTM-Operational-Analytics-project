#************************* Pearson  Correlation**************************************
# fill missing values with the mean value.
df["LoanAmount"]=df["LoanAmount"].fillna(df["LoanAmount"].mean())
# calculate Pearson correlation coefficient
pcc = np.corrcoef(df['ApplicantIncome'], df['LoanAmount'])
print("Result:")
print(f"r={pcc}")

# plot the relationship between LoanAmount and ApplicantIncome
plt.plot(df['LoanAmount'],df['ApplicantIncome'], marker='.', linewidth=0)
plt.ylabel("Applicant Income [Euro]")
plt.xlabel("Loan Amount [Euro]")
plt.title("LoanAmount vs ApplicantIncome")
plt.show();

# show columns that are more correlated using seaborns pairplot
# imputation of na values just for quick analysis
new_df = df.fillna(0) # fillna
import seaborn as sns # import seaborn
sns.pairplot(df, hue ='Education')
plt.show();
plt.title("Pair-plot of the numeric values");


# select numeric column only
num = new_df.select_dtypes(include=np.number)
# create the pearson correlation output as a variable
pearsonCorr = num.corr(method ='pearson')
# display using heatmaps
sns.heatmap(pearsonCorr, annot=True);
plt.title("Including binary categorical variables")
plt.suptitle("Correlation between numeric value");
plt.show();

pass