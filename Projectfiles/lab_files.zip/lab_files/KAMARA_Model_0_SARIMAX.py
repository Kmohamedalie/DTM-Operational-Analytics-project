# import the packages
import pandas as pd
import numpy as np
from statsmodels.tsa.statespace.sarimax import SARIMAX
import matplotlib.pyplot as plt
from statsmodels.tsa.stattools import acf

# Preprocessing, log - diff transform
df = pd.read_csv('food_retail.csv', header=0)
sales = df['sales'].to_numpy() # array of sales data
logdata = np.log(sales) # log transform

logdiff = pd.Series(logdata).diff() # logdiff transform

# Preprocessing, train and test set
cutpoint = int(0.7*len(logdiff))
train = sales[:362]
test = sales[362:]


# Postprocessing, reconstruction
sarima_model = SARIMAX(train, order=(0,2,2), seasonal_order=(0,1,0,4))
sfit = sarima_model.fit()


# ***** Predictions in-sample: ********
ypred = sfit.predict(len(train),len(train)+11)
plt.plot(train)
plt.plot(np.linspace(len(train),len(train)+12,12),ypred)
plt.xlabel('Date');plt.ylabel('Retail sales')
plt.title("Retail Sales prediction with SARIMAX")
plt.show()


######## ****************** Accuracy metrics ************************
def forecast_accuracy(forecast, actual):
    mape = np.mean(np.abs(forecast - actual)/np.abs(actual)) # MAPE
    me = np.mean(forecast - actual) # ME
    mae = np.mean(np.abs(forecast - actual)) # MAE
    mpe = np.mean((forecast - actual)/actual) # MPE
    rmse = np.mean((forecast - actual)**2)**.5 # RMSE
    corr = np.corrcoef(forecast, actual)[0,1] # correlation coeff
    mins = np.amin(np.hstack([forecast[:,None], actual[:,None]]), axis=1)
    maxs = np.amax(np.hstack([forecast[:,None], actual[:,None]]), axis=1)
    minmax = 1 - np.mean(mins/maxs) # minmax
    acf1 = acf(forecast-actual)[1] # ACF1
    return({'mape':mape, 'me':me, 'mae': mae, 'mpe': mpe, 'rmse':rmse,'acf1':acf1, 'corr':corr, 'minmax':minmax})

# instatiate the values to calculate the metric evaluation
forecast_values = np.array(ypred)
actual_vaues = np.array(test)

# output the accuracy
print("THE METRICS:\n",forecast_accuracy(ypred, test));