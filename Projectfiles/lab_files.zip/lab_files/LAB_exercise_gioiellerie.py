import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv(r"C:\Users\mediaworld\PycharmProjects\Predictive_Analytics\gioiellerie.csv")
df.head()

plt.figure(figsize=(8,4))
plt.plot(df.sales,label="gioiellerie Stati Uniti (1992-2016)")
plt.legend()
plt.show()
