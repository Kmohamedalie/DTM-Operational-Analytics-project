class MonteCarlo:
    def __init__(self, ticker, iteration):
        self.ticker = ticker
        self.iteration = iteration

    def runSimulation(self):

        print("Hello and Welcome to Monte Carlo Simulation")
        print("*******************************************")
        print("please enter below the ticker of the the stock you want to \n simulate and sample/iterations!")
        ticker = str(input("ticker: "))
        iteration = int(input("iteration: "))
        self.ticker = ticker # assign the new ticker

        # import all necessary library
        import yfinance as yf
        import numpy as np
        import matplotlib.pyplot as plt

        # download stock data using ticker
        df = yf.download(ticker)

        # calculate the return using pct_change method
        returns = np.log(1 + df['Adj Close'].pct_change())

        # calculate the mean and standard deviation of the returns
        mu, sigma, var = returns.mean(), returns.std(), returns.var()

        # BROWNIAN MOTION
        # Formula = drift + standard deviation * e^r
        # drift = mean - 1/2(variance)


        # get the most recent price
        initial = df['Adj Close'].iloc[-1]

        # display the simulated prices of the ticker and iterations
        # for the next 252 trading days / Random walk
        for i in range(iteration):
            # create a normal distribution and simulate for the next 252 trading days
            sim_rets = np.random.normal(mu, sigma, 252)
            # generated prices of ticker in one year
            sim_prices = initial * (sim_rets + 1).cumprod()
            # labels and plots

            plt.xlabel('days')
            plt.ylabel('Simulated Prices')
            plt.title(f'{self.ticker} simulated prices for the 252 trading days')
            plt.plot(sim_prices)
        plt.axhline(initial, c='k')
        plt.show()


Run = MonteCarlo('TSLA', 100) # setting default ticker to TSLA and iteration 100
Run.runSimulation()


pass