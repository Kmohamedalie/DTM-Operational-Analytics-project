# -*- coding: utf-8 -*-
"""
Created on Fri Mar  3 18:10:36 2023

@author: mediaworld
"""

import hvplot.pandas
from bokeh.sampledata.penguins import data as df

df.hvplot.scatter(x='bill_length_mm', y='bill_depth_mm', by='species')