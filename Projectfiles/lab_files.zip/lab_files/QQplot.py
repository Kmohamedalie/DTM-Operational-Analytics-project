import numpy as np
import matplotlib.pyplot as plt
from statsmodels.graphics.gofplots import qqplot
data = np.array([-4,-3,0.8,1.8,3.9,6.2,6.5])

# q-q plot
plt.title("QQplot")
qqplot(data, line='q')
plt.show()