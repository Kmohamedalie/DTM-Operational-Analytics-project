# import the packages
import pandas as pd
import numpy as np
from statsmodels.tsa.statespace.sarimax import SARIMAX
import pmdarima as pm
import matplotlib.pyplot as plt

# Preprocessing, log - diff transform
df = pd.read_csv(r'C:\Users\mohamedalie.kamara\PycharmProjects\OperationalAnalytics\FilRouge.csv', header=0)
aSales = df['sales'].to_numpy() # array of sales data
logdata = np.log(aSales) # log transform

logdiff = pd.Series(logdata).diff() # logdiff transform

# Preprocessing, train and test set
cutpoint = int(0.7*len(logdiff))
train = logdiff[:cutpoint]
test = logdiff[cutpoint:]

# Postprocessing, reconstruction
train[0] = 0 # set first entry
reconstruct = np.exp(np.r_[train,test].cumsum()+logdata[0])

isPm = True

if isPm:
    print("Here is Pm")
    # Parameter fitting
    model = pm.auto_arima(aSales, start_p=1, start_q=1,
                          test='adf', max_p=3, max_q=3, m=4,
                          start_P=0, seasonal=True,
                          d=None, D=1, trace=True,
                          error_action='ignore',
                          suppress_warnings=True,
                          stepwise=True)  # False full grid
    print(model.summary())
    morder = model.order
    mseasorder = model.seasonal_order
    fitted = model.fit(aSales)
    yfore = fitted.predict(n_periods=4)  # forecast
    ypred = fitted.predict_in_sample()
    plt.plot(aSales)
    plt.plot(ypred)
    plt.plot([None for i in ypred] + [x for x in yfore])
    plt.xlabel('time');
    plt.ylabel('sales')
    plt.title("Pmdarima forecast")
    plt.show()

else:
    # Preprocessing, log - diff transform
    df = pd.read_csv(r'C:\Users\mohamedalie.kamara\PycharmProjects\OperationalAnalytics\FilRouge.csv', header=0)
    aSales = df['sales'].to_numpy()  # array of sales data
    logdata = np.log(aSales)  # log transform

    logdiff = pd.Series(logdata).diff()  # logdiff transform

    # Preprocessing, train and test set
    cutpoint = int(0.7 * len(logdiff))
    train = logdiff[:cutpoint]
    test = logdiff[cutpoint:]

    # Postprocessing, reconstruction
    train[0] = 0  # set first entry
    reconstruct = np.exp(np.r_[train, test].cumsum() + logdata[0])

    from statsmodels.tsa.statespace.sarimax import SARIMAX

    sarima_model = SARIMAX(aSales, order=(0, 2, 2), seasonal_order=(0, 1, 0, 4))
    sfit = sarima_model.fit()
    # sfit.plot_diagnostics(figsize=(10, 6))
    # plt.show()

    # ***** Predictions in-sample: ********
    ypred = sfit.predict(start=0, end=len(df))
    # plt.plot(df.sales)
    # plt.plot(ypred)
    # plt.xlabel('time');plt.ylabel('sales')
    # plt.title("Sales and prediction")
    # plt.show()

    # **** Forecast, out-of-sample *********
    forewrap = sfit.get_forecast(steps=4)
    forecast_ci = forewrap.conf_int()
    forecast_val = forewrap.predicted_mean
    plt.plot(df.sales)
    plt.fill_between(np.linspace(len(df), len(df) + 4, 4),
                     forecast_ci[:, 0],
                     forecast_ci[:, 1], color='k', alpha=.25)
    plt.plot(np.linspace(len(df), len(df) + 4, 4), forecast_val)
    plt.xlabel('time');
    plt.ylabel('sales')
    plt.title("Forecast out-of-sample")
    plt.show()

pass