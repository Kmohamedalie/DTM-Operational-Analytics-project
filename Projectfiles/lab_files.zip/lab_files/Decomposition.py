import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.seasonal import seasonal_decompose


df = pd.read_csv(r"C:\Users\mediaworld\PycharmProjects\Predictive_Analytics\yfinance.csv")
df.head()
plt.rcParams['figure.figsize'] = (10.0, 6.0)
df = pd.read_csv('BoxJenkins.csv',usecols=["Passengers"])
ds = df[df.columns[0]] # converts to series
result = seasonal_decompose(ds, model='multiplicative',period=12)
result.plot()
plt.show()
