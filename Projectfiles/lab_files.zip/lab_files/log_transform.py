import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

ds = pd.read_csv(r"C:\Users\mediaworld\PycharmProjects\Predictive_Analytics\BoxJenkins.csv")
X = ds.Passengers.values

# step 1 log.
# take the logarithm of the original dataset
log_x = np.log(X)

# step 2 diff.
# log diff minus previous value
log_x_xdiff = [log_x[i] - log_x[i-1] for i in range(1,len(log_x))]

# step 3 plot log diff
# plt.plot(log_x_diff)
# plt.ylabel("Passengers")
# plt.title("log diff")


# step 4 invert the log diff
# the invert of the log diff
invert_diff = [log_x_xdiff[i] + log_x_xdiff[i-1] for i in range(1,len(log_x_xdiff))]
invert_diff

plt.plot(invert_diff)
plt.title("inverted log diff")
plt.show()

pass



