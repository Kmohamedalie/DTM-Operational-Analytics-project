import pandas as pd
import plotly.express as px

df = pd.read_csv(r"C:\Users\mediaworld\PycharmProjects\Predictive_Analytics\FilRougePython.csv")
fig = px.line(df, x='t', y = "sales",trendline="ols") # ,render_mode="webgl", ,animation_frame='Date'
fig.update_layout(
    title="Linear trend Model",
    xaxis_title="t",
    yaxis_title="Sales")

fig.show()
