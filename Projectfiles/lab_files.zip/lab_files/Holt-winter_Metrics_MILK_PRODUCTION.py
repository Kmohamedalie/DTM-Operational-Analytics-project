# ***********************  Holtz-Winters Milk Production **********************************
# import the packages
import numpy as np
from statsmodels.tsa.statespace.sarimax import SARIMAX
import matplotlib.pyplot as plt
import os, numpy as np, pandas as pd
from statsmodels.tsa.stattools import acf

# read df
df = pd.read_csv('monthly_milk_production.csv', header=0)
df.head()

# Preprocessing, log - diff transform
prod = df['Production'].to_numpy() # array of sales data
logdata = np.log(prod) # log transform

logdiff = pd.Series(logdata).diff() # logdiff transform

# Preprocessing, train and test set
cutpoint = int(0.7*len(logdiff))
position = 168-12
train = prod[:156]
test = prod[156:]


# fit model
from statsmodels.tsa.holtwinters import ExponentialSmoothing
model = ExponentialSmoothing(train, seasonal_periods=4,trend="add",
seasonal="mul",
damped_trend=True,
use_boxcox=True,
initialization_method="estimated")
hwfit = model.fit()
# make forecast
yfore = hwfit.predict(len(train), len(train)+11)
print(yfore)
len(yfore)

# ***** Predictions in-sample: ********
plt.plot(train)
#plt.plot(yfore)
plt.plot(np.linspace(len(train),len(train)+12,12),yfore)
plt.xlabel('Date');plt.ylabel('Production')
plt.title("Holtz- winters Milk-Production")
plt.show()



#******************************** Accuracy *******************************
# Accuracy metrics
def forecast_accuracy(forecast, actual):
    mape = np.mean(np.abs(forecast - actual)/np.abs(actual)) # MAPE
    me = np.mean(forecast - actual) # ME
    mae = np.mean(np.abs(forecast - actual)) # MAE
    mpe = np.mean((forecast - actual)/actual) # MPE
    rmse = np.mean((forecast - actual)**2)**.5 # RMSE
    corr = np.corrcoef(forecast, actual)[0,1] # correlation coeff
    mins = np.amin(np.hstack([forecast[:,None], actual[:,None]]), axis=1)
    maxs = np.amax(np.hstack([forecast[:,None], actual[:,None]]), axis=1)
    minmax = 1 - np.mean(mins/maxs) # minmax
    acf1 = acf(forecast-actual)[1] # ACF1
    return({'mape':mape, 'me':me, 'mae': mae, 'mpe': mpe, 'rmse':rmse,'acf1':acf1, 'corr':corr, 'minmax':minmax})

# assign the forecast and test variables
forecast_values = np.array(yfore)
actual_vaues = np.array(test)
# print the values of the metrics
print( forecast_accuracy(forecast_values, test))
#%%
