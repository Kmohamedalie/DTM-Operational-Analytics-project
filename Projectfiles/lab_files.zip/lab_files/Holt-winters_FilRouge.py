# import the packages
import pandas as pd
import numpy as np
from statsmodels.tsa.statespace.sarimax import SARIMAX
import matplotlib.pyplot as plt

# Preprocessing, log - diff transform
df = pd.read_csv('FilRouge.csv', header=0)
aSales = df['sales'].to_numpy() # array of sales data
logdata = np.log(aSales) # log transform

logdiff = pd.Series(logdata).diff() # logdiff transform

# Preprocessing, train and test set
cutpoint = int(0.7*len(logdiff))
train = aSales[:16]
test = aSales[16:]

from statsmodels.tsa.holtwinters import ExponentialSmoothing
# fit model
model = ExponentialSmoothing(train, seasonal_periods=4,trend="add",
seasonal="mul",
damped_trend=True,
use_boxcox=True,
initialization_method="estimated")
hwfit = model.fit()
# make forecast
yfore = hwfit.predict(len(train), len(train)+3)
print(yfore)


# ***** Predictions in-sample: ********
plt.plot(train)
#plt.plot(yfore)
plt.plot(np.linspace(len(train),len(train)+4,4),yfore)
plt.xlabel('time');plt.ylabel('sales')
plt.title("Holtz- winters")
plt.show()