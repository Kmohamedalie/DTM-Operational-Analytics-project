# import liabraries
from sklearn.svm import SVR
from sklearn.datasets import make_regression
import pandas as pd
from pandas import MultiIndex, Int64Index
import matplotlib.pyplot as plt

df = pd.read_csv(r'C:BoxJenkins.csv', usecols=[1], names=['Passengers'],header=0)

# split into train and test sets
# rolling window dataset
dataset = pd.DataFrame()

for i in range(10, 0, -1):
  dataset['t-' + str(i)] = df.Passengers.shift(i)
  dataset['t'] = df.Passengers.values
dataset = dataset[10:] # df starts from 0

# train test split
x = dataset.iloc[:, :-1]
y = dataset.iloc[:, -1]
x_train, xtest = x[:-12], x[-12:]
y_train, ytest = y[:-12], y[-12:]

# fit model
model = SVR(kernel = 'linear') # linear, poly, rbf, sigmoid
model.fit(x_train, y_train)

# make a one-step prediction
yhat = model.predict(xtest)

# plot the chart
# plt.plot([None for i in y_train] + [x for x in ytest], "-o", label="actual")
# plt.plot([None for i in y_train] + [x for x in yhat], "-o", label="forecast")
plt.plot(y_train.index,y_train, "-o", label="train")
plt.plot(ytest.index, ytest, "-o", label="actual")
plt.plot(ytest.index,yhat, "-o", label="forecast")
plt.title("Boxjenkins with Support Vector Regressor")
plt.legend()
plt.show()