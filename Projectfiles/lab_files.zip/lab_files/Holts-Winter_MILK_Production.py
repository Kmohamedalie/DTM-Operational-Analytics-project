# import the packages
import pandas as pd
import numpy as np
from statsmodels.tsa.statespace.sarimax import SARIMAX
import matplotlib.pyplot as plt

# read df
df = pd.read_csv('monthly_milk_production.csv', header=0)
df.head()

# Preprocessing, log - diff transform
prod = df['Production'].to_numpy() # array of sales data
logdata = np.log(prod) # log transform

logdiff = pd.Series(logdata).diff() # logdiff transform

# Preprocessing, train and test set
cutpoint = int(0.7*len(logdiff))
position = 168-12
train = prod[:157]
test = prod[157:]

# holt-winters model
from statsmodels.tsa.holtwinters import ExponentialSmoothing
# fit model
model = ExponentialSmoothing(train, seasonal_periods=4,trend="add",
seasonal="mul",
damped_trend=True,
use_boxcox=True,
initialization_method="estimated")
hwfit = model.fit()
# make forecast
yfore = hwfit.predict(len(train), len(train)+11)
print(yfore)

# ***** Predictions in-sample: ********
plt.plot(train)
#plt.plot(yfore)
plt.plot(np.linspace(len(train),len(train)+12,12),yfore)
plt.xlabel('Date');plt.ylabel('Production')
plt.title("Holtz- winters Milk-Production")
plt.show()