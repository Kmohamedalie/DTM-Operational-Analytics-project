import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import shapiro
from statsmodels.graphics.gofplots import qqplot


# read the loan data
df = pd.read_csv("Dataset.csv")
LoanAmount = df['LoanAmount']
data = LoanAmount.fillna(LoanAmount.mean()).to_numpy()


# normality test
alpha = 0.05
stat, p = shapiro(data)

# Shapiro-Wilk Test
print("Shapiro-Wilk Test ********************************")
print('Shapiro=%.3f, p=%.3f, alpha=%.3f' % (stat, p, alpha))
if p > alpha:
 print('Campione gaussiano (non rifiuto H0)')
else:
 print('Campione NON gaussiano (rifiuto H0)')


print("\n"*2)
# Kolmogorov-Smirnov Test
print("Kolmogorov-Smirnov Test ****************************")
from scipy.stats import kstest


stat, p = kstest(data, 'norm')
print('Kolmogorov=%.3f, p=%.3f, alpha=%.3f' % (stat, p, alpha))

# test
if p > alpha:
     print('Campione gaussiano (non rifiuto H0)')
else:
     print('Campione NON gaussiano (rifiuto H0)')


# loan distribution
#plt.hist(data);
qqplot(data, line='q')
plt.title("Loan Amount Distribution")
plt.ylabel("Loan amount [euro]")
plt.show()


pass