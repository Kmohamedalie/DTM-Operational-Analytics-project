from xgboost import XGBRegressor
import pandas as pd
from pandas import MultiIndex, Int64Index
import matplotlib.pyplot as plt
import numpy as np

df = pd.read_csv(r'C:BoxJenkins.csv', usecols=[1], names=['Passengers'],header=0)

# split into train and test sets
# rolling window dataset
lookback = 12
dataset = pd.DataFrame()

for i in range(lookback, 0, -1):
  dataset['t-' + str(i)] = df.Passengers.shift(i)
  dataset['t'] = df.Passengers.values
dataset = dataset[lookback:] # removes the first lookback columns

# train test split
x = dataset.iloc[:, :-1]
y = dataset.iloc[:, -1]
x_train, xtest = x[:-12], x[-12:]
y_train, ytest = y[:-12], y[-12:]

# fit model
model = XGBRegressor(objective='reg:squarederror', n_estimators=1000)
model.fit(x_train, y_train)

# make a one-step prediction
yhat = model.predict(xtest)

# plot the chart
plt.plot(y_train.index,y_train, "-o", label="train")
plt.plot(ytest.index, ytest, "-o", label="actual")
plt.plot(ytest.index,yhat, "-o", label="forecast")
plt.title("Boxjenkins with Xgboost")
plt.legend()
plt.show()