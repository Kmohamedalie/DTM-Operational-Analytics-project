# import the packages
import numpy as np, pandas as pd
import matplotlib.pyplot as plt
from keras.models import Sequential
from keras.layers import Dense
import math

# setting a random seed
np.random.seed(550) # for reproducibility


# Preprocessing, load the dataset
df = pd.read_csv(r'C:BoxJenkins.csv', usecols=[1], names=['Passengers'],header=0)
dataset = df.values # time series values
dataset = dataset.astype('float32') # needed for MLP input

# split into train and test sets
train_size = int(len(dataset) - 12)
test_size = len(dataset) - train_size
train, test = dataset[0:train_size,:], dataset[train_size:len(dataset),:]
print("Len train={0}, len test={1}".format(len(train), len(test)))

# scaling the data
from sklearn.preprocessing import MinMaxScaler
scaler = MinMaxScaler()
scaler.fit_transform(train.reshape(-1, 1))
scaled_train_data = scaler.transform(train.reshape(-1, 1))
scaled_test_data = scaler.transform(test.reshape(-1, 1))


# timeseriesGenerator for LSTM
from keras.preprocessing.sequence import TimeseriesGenerator
n_input = 12; n_features = 1
generator = TimeseriesGenerator(scaled_train_data, scaled_train_data, length=n_input,
batch_size=1)


# import libraries for the LSTM RNN
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import LSTM

# instatiate the model
lstm_model = Sequential()
lstm_model.add(LSTM(20, activation='relu', input_shape=(n_input, n_features), dropout=0.05))
lstm_model.add(Dense(1))
lstm_model.compile(optimizer='adam', loss='mse')
lstm_model.fit(generator,epochs=25)
lstm_model.summary()


# plot the loss of the model
losses_lstm = lstm_model.history.history['loss']
plt.xticks(np.arange(0,21,1)) # convergence trace
plt.plot(range(len(losses_lstm)),losses_lstm);
plt.show()


# curbatch
lstm_predictions_scaled = list()
batch = scaled_train_data[-n_input:]
curbatch = batch.reshape((1, n_input, n_features)) # 1 dim more

# iterate and append to curbatch
for i in range(len(test)):
   lstm_pred = lstm_model.predict(curbatch)[0]
   lstm_predictions_scaled.append(lstm_pred)
   curbatch = np.append(curbatch[:,1:,:],[[lstm_pred]],axis=1)

# revese the values and transpose
lstm_forecast = scaler.inverse_transform(lstm_predictions_scaled)
yfore = np.transpose(lstm_forecast).squeeze()


# recostruction
expdata = train # unlog
expfore = yfore
plt.plot(df.Passengers, label="Passengers")
plt.plot(expdata,label='expdata')
plt.plot([None for x in expdata]+[x for x in expfore], label='forecast')
plt.legend()
plt.title("Boxjenkins Forecast")
plt.show()
