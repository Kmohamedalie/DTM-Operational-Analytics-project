# Kolmogorov-Smirnov Test
print("Kolmogorov-Smirnov Test ****************************")
from scipy.stats import kstest
stat, p = kstest(data,'norm')
print('Kolmogorov=%.3f, p=%.3f, alpha=%.3f' % (stat, p, alpha))

# test
if p > alpha:
 print('Campione gaussiano (non rifiuto H0)')
else:
 print('Campione NON gaussiano (rifiuto H0)')


pass