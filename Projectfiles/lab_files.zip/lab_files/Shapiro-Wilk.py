import numpy as np
from scipy.stats import shapiro
# generate data
np.random.seed()
data = 20 * np.random.randn(100) + 100
# normality test
alpha = 0.05
stat, p = shapiro(data)

# Shapiro-Wilk Test
print("Shapiro-Wilk Test ********************************")
print('Shapiro=%.3f, p=%.3f, alpha=%.3f' % (stat, p, alpha))
if p > alpha:
 print('Campione gaussiano (non rifiuto H0)')
else:
 print('Campione NON gaussiano (rifiuto H0)')