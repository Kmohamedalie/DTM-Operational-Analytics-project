
# import all necessary library
import yfinance as yf
import numpy as np
import matplotlib.pyplot as plt

# download stock data using ticker
df = yf.download('MSFT')

# calculate the return
returns = np.log(1 + df['Adj Close'].pct_change())

# calculate the mean and standard deviation of the returns
mu, sigma = returns.mean(), returns.std()

# create a normal distribution and simulate for the next 252 trading days
sim_rets = np.random.normal(mu, sigma, 252)

# get the most recent price
initial = df['Adj Close'].iloc[-1]

# generated prices of ticker in one year
sim_prices = initial * (sim_rets + 1).cumprod()

# display the simulated prices of tesla for the next 252 trading days / Random walk
for i in range(100):
    # create a normal distribution and simulate for the next 252 trading days
    sim_rets = np.random.normal(mu, sigma, 252)
    # generated prices of ticker in one year
    sim_prices = initial * (sim_rets + 1).cumprod()
    plt.axhline(initial, c='k')
    plt.xlabel('days')
    plt.ylabel('Simulated Prices')
    plt.title(f'TSLA simulated prices for the 252 trading days')
    plt.plot(sim_prices)
plt.show()
