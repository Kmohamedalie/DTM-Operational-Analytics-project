# import the packages
import pandas as pd
import numpy as np
from statsmodels.tsa.statespace.sarimax import SARIMAX
import matplotlib.pyplot as plt

# Preprocessing, log - diff transform
df = pd.read_csv('FilRouge.csv', header=0)
aSales = df['sales'].to_numpy() # array of sales data
logdata = np.log(aSales) # log transform

logdiff = pd.Series(logdata).diff() # logdiff transform

# Preprocessing, train and test set
cutpoint = int(0.7*len(logdiff))
train = aSales[:16]
test = aSales[16:]


# Postprocessing, reconstruction
sarima_model = SARIMAX(train, order=(0,2,2), seasonal_order=(0,1,0,4))
sfit = sarima_model.fit()


# ***** Predictions in-sample: ********
ypred = sfit.predict(start=0,end=len(train))
plt.plot(train)
plt.plot(ypred)
plt.xlabel('time');plt.ylabel('sales')
plt.title("Sales and prediction")
plt.show()

# **** Forecast, out-of-sample *********
forewrap = sfit.get_forecast(steps=4)
forecast_ci = forewrap.conf_int()
forecast_val = forewrap.predicted_mean
plt.plot(train)
plt.fill_between(np.linspace(len(train),len(train)+4,4),
forecast_ci[:, 0],
forecast_ci[:, 1], color='k', alpha=.25)
plt.plot(np.linspace(len(train),len(train)+4,4),forecast_val)
plt.xlabel('time');
plt.ylabel('sales')
plt.title("Forecast out-of-sample")
plt.show()