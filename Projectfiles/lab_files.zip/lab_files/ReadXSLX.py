# -*- coding: utf-8 -*-
"""
Created on Fri Mar  3 17:17:44 2023

@author: mediaworld
"""

# conda install openpyxl
# pip install openpyxl

import pandas as pd
filepath = r"C:\Users\mediaworld\Desktop\Unibo - Predictive Analytics\FilRougeS.xlsx"

# read xlxsx file directly using there names
excelfile = pd.ExcelFile(filepath) 
sheet1 = excelfile.parse(sheet_name='FilRouge', index_col=None,parse_dates=True)
sheet2 = excelfile.parse(sheet_name='duplicate', index_col=None,parse_dates=True)
excelfile.sheet_names

# read as a dictionary  ******************************************************
ts = pd.read_excel(filepath, engine='openpyxl', index_col=None, sheet_name=None, parse_dates=True)
# access the dict by key values
ts.keys()
# use keys to access each sheet 
ts['FilRouge']


# plot
# import matplotlib.pyplot as plt
# plt.plot(ts['duplicate']['t'],ts['duplicate']['sales'])