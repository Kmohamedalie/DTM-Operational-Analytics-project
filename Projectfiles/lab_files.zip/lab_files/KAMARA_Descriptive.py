import numpy as np
import pandas as pd
from scipy.stats import norm
from sklearn.preprocessing import StandardScaler
from scipy import stats # to be used later
import matplotlib.pyplot as plt
import os
df = pd.read_csv(r"C:\Users\mediaworld\PycharmProjects\Predictive_Analytics\traffico16.csv") # dataframe (series)
npa = df['ago1'].to_numpy() # numpy array


# # ********************** Histogram ***************************************
plt.hist(npa, bins=10, color='#00AA00', edgecolor='black')
plt.title(df.columns[0])
plt.xlabel('num')
plt.ylabel('days')
plt.show()


# ********************** Boxplot ***************************************
df.boxplot(column=['ago1', 'ago2'])
plt.boxplot(npa) # single npa
plt.show()


# ********************** Scatter ***************************************
plt.scatter(df['ago1'][:20].sort_values(),df['set1'][:20].sort_values() )
plt.xlabel('ago1')
plt.ylabel('set1')
plt.title("ago1 vs set1")
plt.show()


# ********************** NormCDF ***************************************
df_ago1 = np.array(npa).reshape(len(npa), 1)

Mean = df_ago1.mean()
Std = df_ago1.std()

dom = np.arange(-2,1,0.01) # domain of x values
# plot the value
plt.plot(dom, norm.cdf(dom,Mean, Std), label=f"std:{int(Std)}")
plt.title("traffico CDF")
plt.legend()
plt.show()



# ********************** NormPDF ***************************************
df_ago2 = np.array(npa).reshape(len(npa), 1)

Mean = df_ago2.mean()
Std = df_ago2.std()
# self define NORMpdf function
def NORMpdf(x,Mean,Std):
    import numpy as np
    X = x.copy()
    X = X.astype(int)

    e = 2.718281828459045
    power = (-(((dom - Mean) ** 2) / (2 * Std * Std)))
    eulerp = e**power
    fx = (1/np.sqrt(2*3.123*Std**2))*eulerp
    return fx

plt.plot(dom, NORMpdf(dom, Mean, Std), label=f'std: {Std}')
# plt.plot(dom, norm.pdf(dom, Mean, Std), label=f'std: {Std}')
plt.title("traffico PDF")
plt.legend()
plt.show()
