#**********************  MLP ********************************+
# import the packages
import numpy as np, pandas as pd
import matplotlib.pyplot as plt
from keras.models import Sequential
from keras.layers import Dense
import math

# converts an array of values into two np arrays
def create_dataset(dataset, look_back=1):
   dataX, dataY = [], []
   for i in range(len(dataset) - look_back):
       a = dataset[i:(i + look_back)]
       dataX.append(a)
       dataY.append(dataset[i + look_back])
   return np.array(dataX), np.array(dataY)

# Preprocessing, log - diff transform
df = pd.read_csv(r'C:BoxJenkins.csv', usecols=[1], names=['Passengers'],header=0)
dataset = df.values # time series values
dataset = dataset.astype('float32') # needed for MLP input

# split into train and test sets
train_size = int(len(dataset) - 12)
test_size = len(dataset) - train_size
train, test = dataset[0:train_size,:], dataset[train_size:len(dataset),:]
print("Len train={0}, len test={1}".format(len(train), len(test)))

# dataset, y = create_dataset(datas,look_back=5)
# sliding window matrices (look_back = window width); dim = n - look_back - 1
look_back = 2
testdata = np.concatenate((train[-look_back:],test))
trainX, trainY = create_dataset(train, look_back)
testX, testY = create_dataset(testdata, look_back)

# Multilayer Perceptron model
loss_function = 'mean_squared_error'
model = Sequential()
model.add(Dense(8, input_dim=look_back, activation='relu')) # 8 hidden neurons
model.add(Dense(1)) # 1 output neuron
model.compile(loss=loss_function, optimizer='adam')
model.fit(trainX, trainY, epochs=200, batch_size=2, verbose=2)

# Estimate model performance
trainScore = model.evaluate(trainX, trainY, verbose=0)
print('Train Score: MSE: {0:0.3f} RMSE: ({1:0.3f})'.format(trainScore,
math.sqrt(trainScore)))
testScore = model.evaluate(testX, testY, verbose=0)
print('Test Score: MSE: {0:0.3f} RMSE: ({1:0.3f})'.format(testScore, math.sqrt(testScore)))
# generate predictions for training and forecast for plotting
trainPredict = model.predict(trainX)
testForecast = model.predict(testX)
plt.plot(dataset)
plt.plot(np.concatenate((np.full(look_back-1, np.nan), trainPredict[:,0])))
plt.plot(np.concatenate((np.full(len(train)-1, np.nan), testForecast[:, 0])))
plt.show()




#********************************* LSTM *******************************
# import the packages
import numpy as np, pandas as pd
import matplotlib.pyplot as plt
from keras.models import Sequential
from keras.layers import Dense
import math

# Preprocessing, load the dataset
df = pd.read_csv(r'C:BoxJenkins.csv', usecols=[1], names=['Passengers'],header=0)
dataset = df.values # time series values
dataset = dataset.astype('float32') # needed for MLP input

# split into train and test sets
train_size = int(len(dataset) - 12)
test_size = len(dataset) - train_size
train, test = dataset[0:train_size,:], dataset[train_size:len(dataset),:]
print("Len train={0}, len test={1}".format(len(train), len(test)))

# scaling the data
from sklearn.preprocessing import MinMaxScaler
scaler = MinMaxScaler()
scaler.fit_transform(train.reshape(-1, 1))
scaled_train_data = scaler.transform(train.reshape(-1, 1))
scaled_test_data = scaler.transform(test.reshape(-1, 1))

# timeseriesGenerator for LSTM
from keras.preprocessing.sequence import TimeseriesGenerator
n_input = 12; n_features = 1
generator = TimeseriesGenerator(scaled_train_data, scaled_train_data, length=n_input,
batch_size=1)

# import libraries for the LSTM RNN
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import LSTM

# instatiate the model
lstm_model = Sequential()
lstm_model.add(LSTM(20, activation='relu', input_shape=(n_input, n_features), dropout=0.05))
lstm_model.add(Dense(1))
lstm_model.compile(optimizer='adam', loss='mse')
lstm_model.fit(generator,epochs=25)
lstm_model.summary()

# plot the loss of the model
losses_lstm = lstm_model.history.history['loss']
plt.xticks(np.arange(0,21,1)) # convergence trace
plt.plot(range(len(losses_lstm)),losses_lstm);
plt.show()

# curbatch
lstm_predictions_scaled = list()
batch = scaled_train_data[-n_input:]
curbatch = batch.reshape((1, n_input, n_features)) # 1 dim more

# iterate and append to curbatch
for i in range(len(test)):
   lstm_pred = lstm_model.predict(curbatch)[0]
   lstm_predictions_scaled.append(lstm_pred)
   curbatch = np.append(curbatch[:,1:,:],[[lstm_pred]],axis=1)

# revese the values and transpose
lstm_forecast = scaler.inverse_transform(lstm_predictions_scaled)
yfore = np.transpose(lstm_forecast).squeeze()

# recostruction
expdata = train # unlog
expfore = yfore
plt.plot(df.Passengers, label="Passengers")
plt.plot(expdata,label='expdata')
plt.plot([None for x in expdata]+[x for x in expfore], label='forecast')
plt.legend()
plt.title("Boxjenkins Forecast")
plt.show()






#******************************  DM_test **************************************
# dm_test function
def dm_test(actual_lst, pred1_lst, pred2_lst, h=1, crit="MSE", power=2):
    # Routine for checking errors
    def error_check():
        rt = 0
        msg = ""
        # Check if h is an integer
        if (not isinstance(h, int)):
            rt = -1
            msg = "The type of the number of steps ahead (h) is not an integer."
            return (rt, msg)
        # Check the range of h
        if (h < 1):
            rt = -1
            msg = "The number of steps ahead (h) is not large enough."
            return (rt, msg)
        len_act = len(actual_lst)
        len_p1 = len(pred1_lst)
        len_p2 = len(pred2_lst)
        # Check if lengths of actual values and predicted values are equal
        if (len_act != len_p1 or len_p1 != len_p2 or len_act != len_p2):
            rt = -1
            msg = "Lengths of actual_lst, pred1_lst and pred2_lst do not match."
            return (rt, msg)
        # Check range of h
        if (h >= len_act):
            rt = -1
            msg = "The number of steps ahead is too large."
            return (rt, msg)
        # Check if criterion supported
        if (crit != "MSE" and crit != "MAPE" and crit != "MAD" and crit != "poly"):
            rt = -1
            msg = "The criterion is not supported."
            return (rt, msg)
            # Check if every value of the input lists are numerical values
        from re import compile as re_compile
        comp = re_compile("^\d+?\.\d+?$")

        def compiled_regex(s):
            """ Returns True is string is a number. """
            if comp.match(s) is None:
                return s.isdigit()
            return True

        for actual, pred1, pred2 in zip(actual_lst, pred1_lst, pred2_lst):
            is_actual_ok = compiled_regex(str(abs(actual)))
            is_pred1_ok = compiled_regex(str(abs(pred1)))
            is_pred2_ok = compiled_regex(str(abs(pred2)))
            if (not (is_actual_ok and is_pred1_ok and is_pred2_ok)):
                msg = "An element in the actual_lst, pred1_lst or pred2_lst is not numeric."
                rt = -1
                return (rt, msg)
        return (rt, msg)

    # Error check
    error_code = error_check()
    # Raise error if cannot pass error check
    if (error_code[0] == -1):
        raise SyntaxError(error_code[1])
        return
    # Import libraries
    from scipy.stats import t
    import collections
    import pandas as pd
    import numpy as np

    # Initialise lists
    e1_lst = []
    e2_lst = []
    d_lst = []

    # convert every value of the lists into real values
    actual_lst = pd.Series(actual_lst).apply(lambda x: float(x)).tolist()
    pred1_lst = pd.Series(pred1_lst).apply(lambda x: float(x)).tolist()
    pred2_lst = pd.Series(pred2_lst).apply(lambda x: float(x)).tolist()

    # Length of lists (as real numbers)
    T = float(len(actual_lst))

    # construct d according to crit
    if (crit == "MSE"):
        for actual, p1, p2 in zip(actual_lst, pred1_lst, pred2_lst):
            e1_lst.append((actual - p1) ** 2)
            e2_lst.append((actual - p2) ** 2)
        for e1, e2 in zip(e1_lst, e2_lst):
            d_lst.append(e1 - e2)
    elif (crit == "MAD"):
        for actual, p1, p2 in zip(actual_lst, pred1_lst, pred2_lst):
            e1_lst.append(abs(actual - p1))
            e2_lst.append(abs(actual - p2))
        for e1, e2 in zip(e1_lst, e2_lst):
            d_lst.append(e1 - e2)
    elif (crit == "MAPE"):
        for actual, p1, p2 in zip(actual_lst, pred1_lst, pred2_lst):
            e1_lst.append(abs((actual - p1) / actual))
            e2_lst.append(abs((actual - p2) / actual))
        for e1, e2 in zip(e1_lst, e2_lst):
            d_lst.append(e1 - e2)
    elif (crit == "poly"):
        for actual, p1, p2 in zip(actual_lst, pred1_lst, pred2_lst):
            e1_lst.append(((actual - p1)) ** (power))
            e2_lst.append(((actual - p2)) ** (power))
        for e1, e2 in zip(e1_lst, e2_lst):
            d_lst.append(e1 - e2)

            # Mean of d
    mean_d = pd.Series(d_lst).mean()

    # Find autocovariance and construct DM test statistics
    def autocovariance(Xi, N, k, Xs):
        autoCov = 0
        T = float(N)
        for i in np.arange(0, N - k):
            autoCov += ((Xi[i + k]) - Xs) * (Xi[i] - Xs)
        return (1 / (T)) * autoCov

    gamma = []
    for lag in range(0, h):
        gamma.append(autocovariance(d_lst, len(d_lst), lag, mean_d))  # 0, 1, 2
    V_d = (gamma[0] + 2 * sum(gamma[1:])) / T
    DM_stat = V_d ** (-0.5) * mean_d
    harvey_adj = ((T + 1 - 2 * h + h * (h - 1) / T) / T) ** (0.5)
    DM_stat = harvey_adj * DM_stat
    # Find p-value
    p_value = 2 * t.cdf(-abs(DM_stat), df=T - 1)

    # Construct named tuple for return
    dm_return = collections.namedtuple('dm_return', 'DM p_value')

    rt = dm_return(DM=DM_stat, p_value=p_value)

    return rt


# import and test
from dm_test import dm_test
if __name__ == '__main__':
   MLP = testForecast.squeeze() #[417.662,381.815,423.952,469.055, 471.502, 547.532, 639.609,596.040, 477.471, 445.010, 368.674,414.231]
   LSTM=  yfore.squeeze() #[416.999,390.999,418.999,461.000, 471.999, 535.000, 622.000,606.000, 507.999, 461.000, 390.000, 431.999]
   actual = testY.squeeze() # [417,391,419,461,472,535,622,606,508,461,390,432]
   rt = dm_test(actual, MLP, LSTM, h=1, crit="MSE")
   print(rt)


passs
