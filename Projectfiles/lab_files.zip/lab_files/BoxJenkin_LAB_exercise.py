import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv(r"C:\Users\mediaworld\PycharmProjects\Predictive_Analytics\BoxJenkins.csv")
plt.figure(figsize=(8,4))
# Exercise 1
#plt.plot(df.Passengers,label="BoxJenkins passengers")
# Exercise 2
#plt.plot(df['Passengers'],label="BoxJenkins passengers")
# Exercise 3
#plt.plot(df.iloc[:,-1],label="BoxJenkins passengers")
# Exercise 4
plt.plot(df.iloc[len(df)-12:,-1],label="BoxJenkins passengers")
plt.legend()
plt.show()
pass