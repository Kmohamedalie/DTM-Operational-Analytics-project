from scipy.stats import sem,t
import pandas as pd
import numpy as np

# function for calculating the t-test for two independent samples
def ttest(data1, data2, alpha):
    import statistics as s
    mean1, mean2 = s.mean(data1), s.mean(data2) # means
    se1, se2 = sem(data1), sem(data2) # standard errors
    sed = np.sqrt(se1 ** 2.0 + se2 ** 2.0) # standard error on diff between samples
    t_stat = (mean1 - mean2) / sed # t statistic
    degf = len(data1) + len(data2) - 2 # degrees of freedom
    cv = t.ppf(1.0 - alpha, degf) # critical value, ppf percent point function inv. of cdf
    p = (1.0 - t.cdf(abs(t_stat), degf)) * 2.0 # p-value
    return t_stat, degf, cv, p

# read the loan data
df = pd.read_csv("Dataset.csv")
df

# t test function call
data1 = df.loc[df['Gender'] == 'Male', 'ApplicantIncome']
data2 = df.loc[df['Gender'] == 'Female', 'ApplicantIncome']
alpha = 0.05
t, degf, cv, p = ttest(data1, data2, alpha)

print(" t:",t)
print(" degf:",degf)
print(" cv:",cv)
print(" p:",p)

pass